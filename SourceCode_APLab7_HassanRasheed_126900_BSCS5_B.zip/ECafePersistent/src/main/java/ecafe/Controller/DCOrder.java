/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hassa
 */
public class DCOrder {
    Connection cn;
    Statement st;
    ResultSet rs;
    
    public void connecttodb(){
        try{
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    public void closedb(){
        try {
            cn.close();
            st.close();
            rs.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(DCOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteorder() throws SQLException{
        System.out.println("Enter the Order ID that you want to delete:");
        Scanner input=new Scanner(System.in);
        int orderid=input.nextInt();
        String sql="DELETE FROM `orders` WHERE OrderID=?";
        String sql2="DELETE FROM `order_food` WHERE OrderID=?";
        connecttodb();
        PreparedStatement pst = cn.prepareStatement(sql);
        pst.setInt(1,orderid);
        pst.execute();
        pst.clearParameters();
        pst = cn.prepareStatement(sql2);
        pst.setInt(1, orderid);
        pst.execute();
        pst.close();
        closedb();
    }
}



