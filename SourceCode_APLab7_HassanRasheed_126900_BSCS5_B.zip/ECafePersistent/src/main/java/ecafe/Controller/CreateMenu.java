/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hassa
 */
public class CreateMenu {
    CafeMenu myMenu=new CafeMenu();
    Connection cn;
    Statement st;
    ResultSet rs;
    public CreateMenu(){}
    public void CreatingMenu1(){
        String name, type, description; 
        double price, minutesTomake;
        int id;
        for(int i=0;i<15;i++){
            Scanner inputString=new Scanner(System.in);
            Scanner inputDouble=new Scanner(System.in);
            System.out.println("Enter ID of the Food Item "+(i+1)+":");
            id=inputString.nextInt();
            System.out.println("Enter name of the Food Item "+(i+1)+":");
            name=inputString.nextLine();
            System.out.println("Enter type of the Food Item "+(i+1)+":");
            type=inputString.nextLine();
            System.out.println("Enter price of the Food Item "+(i+1)+":");
            price=inputDouble.nextDouble();
           
            System.out.println("Enter description of the Food Item "+(i+1)+":");
            description=inputString.nextLine();
            FoodItem item=new FoodItem(id,name,type,price,description);
            myMenu.addItem(item);
            System.out.println("Menu Item Added!");
        }
    }
    
    public void connecttodb(){
         try{
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rs=st.executeQuery("select * from items");
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    public void closedb(){
        try {
            cn.close();
            st.close();
            rs.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(CreateMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public CafeMenu CreatingMenu2() throws SQLException{
            connecttodb();
            while(!rs.isLast()){
                rs.next();
                FoodItem item=new FoodItem(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));
                myMenu.addItem(item);
            }
            closedb();
            return myMenu;
    }
    
    public CafeMenu getMenu(){
        return myMenu;
    }
}

