/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hassa
 */
public class SaveOrder {
    
    Connection cn;
    Statement st;
    ResultSet rs;
    
    void connecttodb(){
         try{
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rs=st.executeQuery("select * from orders");
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    void closedb(){
        try {
            cn.close();
            st.close();
            rs.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(CreateOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public SaveOrder(CreateOrder order){
        
    }
    public SaveOrder(){}
    public static void main(String args[]){
        SaveOrder so=new SaveOrder();
        so.connecttodb();
        so.closedb();
    }
}