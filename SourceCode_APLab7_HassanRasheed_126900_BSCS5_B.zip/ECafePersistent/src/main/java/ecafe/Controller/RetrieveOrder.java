/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author hassa
 */
public class RetrieveOrder {
    Connection cn;
    Statement st;
    ResultSet rs;
    
     public void connecttodb(){
         try{
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    public void closedb(){
        try {
            cn.close();
            st.close();
            rs.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(CreateOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void retrieveOrders() throws SQLException{
        System.out.println("Enter the order id you want to retrieve:");
        Scanner scan=new Scanner(System.in);
        int orderid=scan.nextInt();
        String sql="SELECT `OrderID`, `CustomerName`, `Address`, `Total Price`, `Order Time` FROM `orders` WHERE OrderID=?";
        String sql1="SELECT `OrderID`, `FoodID` FROM `order_food` WHERE OrderID=?";
        String sql2="SELECT `ItemID`, `Item Name`, `Type`, `Price`, `Description`, `Prep Time` FROM `items` WHERE ItemID=?";
        connecttodb();
        PreparedStatement pst = cn.prepareStatement(sql);
        pst.setInt(1,orderid);
        rs=pst.executeQuery();
        rs.next();
        String customerName=rs.getString(2);
        String address=rs.getString(3);
        double price=rs.getDouble(4);
        int time=rs.getInt(5);
        System.out.println("Order ID: "+orderid);
        System.out.println("Customer Name: "+customerName);
        System.out.println("Order Price: "+price);
        System.out.println("Order Time: "+time);
        pst.clearParameters();
        pst=cn.prepareStatement(sql1);
        pst.setInt(1, orderid);
        //rs.close();
        rs=pst.executeQuery();
        List<Integer> fooditems = new ArrayList();
        while(!rs.isLast()){
            rs.next();
            fooditems.add(rs.getInt(2));
        }
        pst.clearParameters();
        pst=cn.prepareStatement(sql2);
        List<FoodItem> menuItems=new ArrayList();
        Iterator itr=fooditems.iterator();
        while(itr.hasNext()){
            int fooditemno=(int)itr.next();
            pst.setInt(1,fooditemno);
            rs=pst.executeQuery();
            rs.next();
            FoodItem item=new FoodItem(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));
            menuItems.add(item);
        }
        Iterator itra=menuItems.iterator();
        
        while(itra.hasNext()){
            FoodItem item=(FoodItem)itra.next();
            System.out.println(item.getName()+"\t"+item.getQty()+"\t"+item.getPrice()+"\t"+(item.getQty()*item.getPrice()));
        }
        pst.close();
        closedb();
    }
    
}
