/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hassa
 */
public class CreateOrder {
    
    Connection cn;
    Statement st;
    ResultSet rs;
    
    Connection cna;
    Statement sta;
    ResultSet rsa;
    public int orderid;
    public String customerName;
    public String contactNumber;
    public String address;
    double bill;
    int time;
    List<FoodItem> items=new ArrayList();
    
    public CreateOrder(){}
    
    public void addToOrder(int ID, String itemName,double price, double qty, int time){
        FoodItem item=new FoodItem(ID,itemName,price,qty,time);
        items.add(item);
        this.time=this.time+time;
        this.bill=this.bill+(price*qty);
    }
    
    public int getTime(){
        return time;
    }

    public double getBill(){
        return bill;
    }
    public String getcustomerName(){
        return customerName;
    }
    public String getcontactNumber(){
        return contactNumber;
    }
    public String getAddress(){
        return address;
    }
    public List<FoodItem> getMenuList(){
        return items;
    }
    
    public void connecttodb(){
         try{
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rs=st.executeQuery("select * from orders");
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    public void closedb(){
        try {
            cn.close();
            st.close();
            rs.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(CreateOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void connecttofoodorderdb(){
         try{
        Class.forName("com.mysql.jdbc.Driver");
        cna=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ecafe","root","");
        sta=cna.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rsa=sta.executeQuery("select * from order_food");
        System.out.printf("Connected!");
        }
        catch(Exception e){
        System.out.printf("Connection error! Could not Connect!");
        }
    }
    
    public void closefoodorderdb(){
        try {
            cna.close();
            sta.close();
            rsa.close();
            System.out.printf("Database closed!");
        } catch (SQLException ex) {
            Logger.getLogger(CreateOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void printOrder() throws SQLException {
    //System.out.println(customerName+"\t"+contactNumber+"\t"+address);
    System.out.println("Name:"+customerName+"\nContact Number:"+contactNumber+"\nAddress:"+address+"\n");
    System.out.println("Item\tQuantity\tUnit Price\tTotal Price");
    Iterator itr=items.iterator();
    String sql="INSERT INTO `orders`(`OrderID`, `CustomerName`, `Address`, `Total Price`, `Order Time`) VALUES (?,?,?,?,?)";
    connecttodb();
    PreparedStatement pst=cn.prepareStatement(sql);
    pst.setInt(1,orderid);
    pst.setString(2,customerName);
    pst.setString(3, address);
    pst.setDouble(4, bill);
    pst.setInt(5, time);
    pst.execute();
    pst.close();
    closedb();
    connecttofoodorderdb();
    String sqla="INSERT INTO `order_food`(`OrderID`, `FoodID`) VALUES (?,?)";
    PreparedStatement psta=cna.prepareStatement(sqla);
    while(itr.hasNext()){
        FoodItem item=(FoodItem) itr.next();
        psta.setInt(1,orderid);
        psta.setInt(2,item.getID());
        psta.execute();
        System.out.println(item.getName()+"\t"+item.getQty()+"\t"+item.getPrice()+"\t"+(item.getQty()*item.getPrice()));
    }
    psta.close();
    closefoodorderdb();
    System.out.println("Total Bill:"+bill);
    
    }
    
}
