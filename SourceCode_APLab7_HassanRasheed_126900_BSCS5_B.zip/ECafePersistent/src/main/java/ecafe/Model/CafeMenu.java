/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author hassa
 */
public class CafeMenu implements Serializable {
    public List<FoodItem> MenuList=new ArrayList();

    public CafeMenu(){}
    public CafeMenu(List<FoodItem> FoodItems){
        this.MenuList=FoodItems;
    }
    public CafeMenu(CafeMenu menu){
        this.MenuList=menu.MenuList;
    }
    public void addItem(FoodItem item){
        this.MenuList.add(item);
    }
}




