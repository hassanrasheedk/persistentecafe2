/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Model;

/**
 *
 * @author hassa
 */
public class Customer {
    String name;
    String contactnumber;
    String address;
   public Customer(String name, String contactnumber, String address){
        this.name=name;
        this.contactnumber=contactnumber;
        this.address=address;
    }
   public void printCustomer(){
       System.out.println("Name:"+name+"\nContact Number:"+contactnumber+"\nAddress:"+address+"\n");
   }
}
