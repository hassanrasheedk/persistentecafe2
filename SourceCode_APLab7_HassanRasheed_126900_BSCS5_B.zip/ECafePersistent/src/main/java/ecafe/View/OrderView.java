/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.View;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import ecafe.Controller.CreateMenu;
import ecafe.Controller.CreateOrder;
import ecafe.Model.Customer;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author hassa
 */
public class OrderView {
    static Customer customer;
    
    
    public static void customerDetails(String name, String contactnumber, String address){
        customer=new Customer(name,contactnumber,address);
    }
    
    public static void displayMenu(CafeMenu newmenu) throws SQLException{
        CafeMenu menu=new CafeMenu();
        CreateMenu menuCreate=new CreateMenu();
        menu=menuCreate.CreatingMenu2();
        int i=0;
        for (FoodItem item : menu.MenuList) {
            i++;
            System.out.println(i+":\t"+item.getName()+"\t"+item.getType()+"\t"+item.getPrice()+"\t"+item.getDesc());
        }
    }
    
    public static void takingOrder() throws SQLException{
        Scanner input=new Scanner(System.in);
        CreateOrder co=new CreateOrder();
        Scanner inputab=new Scanner(System.in);
        System.out.println("Enter Order ID");
        Scanner inputabc=new Scanner(System.in);
        co.orderid=inputabc.nextInt();
        System.out.println("Enter Your Name:");
        co.customerName=inputab.nextLine();
        System.out.println("Enter Contact Number:");
        co.contactNumber=inputab.nextLine();
        System.out.println("Enter Your Address:");
        co.address=inputab.nextLine();
        int timefororder=0;
        while(true){
            System.out.println("Enter the serial number of the item you want to select.");
            int choice=input.nextInt();
            System.out.println("Enter quantity:");
            int qty=input.nextInt();
            switch (choice) {
                case 1:  
                    co.addToOrder(1,"Zucchini Parmesan", 275, qty,5);
                    timefororder+=5;
                    break;
                case 2:  
                    co.addToOrder(2,"Buffalo Chicken Tenders", 300, qty,5);       
                    timefororder+=5;
                    break;
                case 3:  
                    co.addToOrder(3,"Hummus", 250, qty,5);
                    timefororder+=5;
                    break;
                case 4:  
                    co.addToOrder(4,"Nachos", 250, qty,5);
                    timefororder+=5;
                    break;
                case 5:  
                    co.addToOrder(5,"Chicken Vegetable Soup", 500, qty,10);
                    timefororder+=10;
                    break;
                case 6:  
                    co.addToOrder(6,"Red Chilli Soup", 300, qty,10);
                    timefororder+=10;
                    break;
                case 7:  
                    co.addToOrder(7,"Orange Chicken Skewers with Jalapeño-Mint Yogurt Dip", 800, qty,15);
                    timefororder+=15;
                    break;
                case 8:  
                    co.addToOrder(8,"Ahi Tuna Poke Pizza", 1000, qty,15);
                    timefororder+=15;
                    break;
                case 9:  
                    co.addToOrder(9,"Tandoori Lamb Pizza", 1000, qty,15);
                    timefororder+=15;
                    break;
                case 10: 
                    co.addToOrder(10,"Lechon", 1800, qty,15);
                    timefororder+=15;
                    break;
                case 11: 
                    co.addToOrder(11,"Master Turkey Meatloaf", 1200, qty,15);
                    timefororder+=15;
                    break;
                case 12: 
                    co.addToOrder(12,"The Best Beefy Vegan Burger", 800, qty,15);
                    timefororder+=15;
                    break;
                case 13: 
                    co.addToOrder(13,"Roasted Mushrooms with Herbs", 200, qty,3);
                    timefororder+=3;
                    break;
                case 14: 
                    co.addToOrder(14,"Couscous & Goat Cheese Stuffed Tomatoes", 200, qty,3);
                    timefororder+=3;
                    break;
                case 15:
                    co.addToOrder(15,"Roasted Cabbage with Bacon", 350, qty,3);
                    timefororder+=3;
                    break;
                default: 
                    System.out.println("Invalid order number");
                    break;
            }
            System.out.println("Do you want to add more items to your order? (Enter y/n)");
            Scanner inputa=new Scanner(System.in);
            String yesno=inputa.nextLine();
            if("Y".equals(yesno)||"y".equals(yesno))
                continue;
            break;
        }
        co.printOrder();
        System.out.println("Time required for order: "+timefororder+" minutes");
    }
    
}
