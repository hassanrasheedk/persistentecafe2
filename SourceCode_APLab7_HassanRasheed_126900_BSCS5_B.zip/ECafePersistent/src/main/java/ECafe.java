
import ecafe.Controller.CreateMenu;
import ecafe.Controller.DCOrder;
import ecafe.Controller.RetrieveOrder;
import ecafe.View.OrderView;
import java.sql.SQLException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author hassa
 */
public class ECafe {
     public static void main(String args[]) throws SQLException{
         Scanner input=new Scanner(System.in);
         System.out.println("Select an option from the menu:");
         System.out.println("1 - Take Order.");
         System.out.println("2 - Retrieve previously saved order.");
         System.out.println("3 - Delete orders served");
         System.out.println("4 - Update customer details");
         System.out.println("5 - Exit");
         int n=input.nextInt();
         if(n==1){
         CreateMenu menuCreate=new CreateMenu();
         OrderView.displayMenu(menuCreate.getMenu());
         OrderView.takingOrder();
         }
         else if(n==2){
             RetrieveOrder ro=new RetrieveOrder();
             ro.retrieveOrders();
         }
         else if(n==3){
             DCOrder dco=new DCOrder();
             dco.deleteorder();
         }
         else if(n==4){
         
         }
         else if(n==5){
             return;
         }
     }
}
