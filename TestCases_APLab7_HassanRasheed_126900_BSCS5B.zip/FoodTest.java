/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javacafe.Food;
import static org.junit.Assert.*;

import org.junit.Test;

/**
 *
 * @author asjad
 */
public class FoodTest {
    
@Test
public void test(){
    Food test1=new Food("Food1",1,250);
    Food test2=new Food("Food2",2,150);
    
    assertEquals(15,test1.calculatetime());
    assertEquals(5,test2.calculatetime());
}

   
}
