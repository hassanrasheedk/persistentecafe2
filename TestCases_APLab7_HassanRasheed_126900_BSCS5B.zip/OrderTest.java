/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.List;
import javacafe.Order;
import javacafe.Food;
import static org.junit.Assert.*;

import org.junit.Test;

/**
 *
 * @author asjad
 */
public class OrderTest {
    
@Test
public void test(){
    List<Food>lf=new ArrayList<Food>();
    Food a=new Food("a",1,2);
    lf.add(a);
   // Order o1=new Order(lf,1);   //Delivery
    Order o2=new Order(lf,2,6);   //TakeAway
    
    assertEquals(2,o2.calculatecost());
    assertEquals(0,o2.getdeliverytime());
}

   
}